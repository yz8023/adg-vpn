#!/system/bin/sh
AGH_DIR="/data/adb/agh"
ADGPATH="/data/adb/modules/AdGuardHome"
PROXY_SCRIPT="$AGH_DIR/scripts/ProxyConfig.sh"

# 检查并停止运行中的进程
while true; do
    found=0
    for p in /proc/[0-9]*; do
        IFS= read -r cmd < "$p/cmdline"
        case "$cmd" in
            "$AGH_DIR/bin/AdGuardHome"*|*"$AGH_DIR/scripts/"*)
                kill -9 "${p#/proc/}"
                found=1
                ;;
        esac
    done
    [ "$found" -eq 0 ] && break
    sleep 1
done

# 还原代理模块修改
[ -f "$PROXY_SCRIPT" ] && "$PROXY_SCRIPT" --clean

# 清理iptables规则残留
iptables -w 2 -t nat -D OUTPUT -j ADGUARD
iptables -w 2 -t nat -F ADGUARD
iptables -w 2 -t nat -X ADGUARD
iptables -w 2 -D OUTPUT -p tcp --dport 853 -j REJECT
iptables -w 2 -D OUTPUT -p udp --dport 853 -j REJECT --reject-with icmp-port-unreachable
iptables -w 2 -D OUTPUT -p udp --dport 443 -j REJECT --reject-with icmp-port-unreachable
iptables -w 2 -t filter -D OUTPUT -j AGH_SNI
iptables -w 2 -t filter -F AGH_SNI
iptables -w 2 -t filter -X AGH_SNI
ip6tables -w 2 -D OUTPUT -j ADGUARD6
ip6tables -w 2 -F ADGUARD6
ip6tables -w 2 -X ADGUARD6
ip6tables -w 2 -D OUTPUT -p tcp --dport 853 -j REJECT
ip6tables -w 2 -D OUTPUT -p udp --dport 853 -j REJECT --reject-with icmp6-port-unreachable
ip6tables -w 2 -D OUTPUT -p tcp --dport 53 -j REJECT
ip6tables -w 2 -D OUTPUT -p udp --dport 53 -j REJECT --reject-with icmp6-port-unreachable
ip6tables -w 2 -D OUTPUT -p udp --dport 443 -j REJECT --reject-with icmp6-port-unreachable
ip6tables -w 2 -t filter -D OUTPUT -j AGH_SNI
ip6tables -w 2 -t filter -F AGH_SNI
ip6tables -w 2 -t filter -X AGH_SNI

# 解除锁定并删除残留文件
_traverse() { if [ -f "$1" ]; then chattr -i "$1"; rm -f "$1"; elif [ -d "$1" ]; then for f in "$1"/*; do [ -e "$f" ] && _traverse "$f"; done; chattr -i "$1"; rmdir "$1"; fi; }; while IFS= read -r line; do case "$line" in *block_ad*) path="${line#*\"}"; path="${path%%\"*}"; [ -n "$path" ] && [ -e "$path" ] && _traverse "$path";; esac; done < "$AGH_DIR/scripts/NoAdsService.sh"

# 解除脚本防篡改保护
find "$AGH_DIR/scripts" "$ADGPATH" -type f -name "*.sh" -exec chattr -i {} \;

# 删除AGH残留目录
[ -d "$AGH_DIR" ] && rm -rf "$AGH_DIR"
[ -d "$ADGPATH" ] && rm -rf "$ADGPATH"