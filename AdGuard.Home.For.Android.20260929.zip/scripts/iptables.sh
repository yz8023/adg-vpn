#!/system/bin/sh
AGH_DIR="/data/adb/agh"
. "$AGH_DIR/scripts/config.prop"
MAIN_LOG="$AGH_DIR/agh.log"

# 防止重复启动
for p in /proc/[0-9]*; do [ "$p" = "/proc/$$" ] && continue; c=; IFS= read -r c < "$p/cmdline"; case "$c" in *"$0"*) exit;; esac; done

# 检测Adguardhome是否存活
agh_running() {
    for p in /proc/[0-9]*; do
        c=
        IFS= read -r c < "$p/cmdline"
        case "$c" in
        "$AGH_DIR/bin/AdGuardHome"*) return 0 ;;
        esac
    done
    return 1
}

# 启动AdGuardHome
start_agh() {
    {
        case "$(getprop persist.sys.locale)" in
            zh*) echo "$(date '+%F %T') AdGuardHome 进程丢失，正在重启..." ;;
            *)   echo "$(date '+%F %T') AdGuardHome process lost, restarting..." ;;
        esac
    } >> "$MAIN_LOG"
    export SSL_CERT_DIR="/system/etc/security/cacerts/"
    "$AGH_DIR/bin/AdGuardHome" --no-check-update &
}

# SNI队列规则：只放行回环，其余指定端口的TCP数据包送入AdGuardHome的NFQUEUE
rebuild_sni() {
    iptables -w 2 -t filter -N AGH_SNI
    iptables -w 2 -t filter -F AGH_SNI
    iptables -w 2 -t filter -A AGH_SNI -o lo -j RETURN
    iptables -w 2 -t filter -A AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags ALL ACK -j RETURN
    iptables -w 2 -t filter -A AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags SYN,FIN,RST NONE \
        -j NFQUEUE --queue-num "$sni_queue" --queue-bypass
    iptables -w 2 -t filter -C OUTPUT -j AGH_SNI || \
        iptables -w 2 -t filter -I OUTPUT 1 -j AGH_SNI
    ip6tables -w 2 -t filter -N AGH_SNI
    ip6tables -w 2 -t filter -F AGH_SNI
    ip6tables -w 2 -t filter -A AGH_SNI -o lo -j RETURN
    ip6tables -w 2 -t filter -A AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags ALL ACK -j RETURN
    ip6tables -w 2 -t filter -A AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags SYN,FIN,RST NONE \
        -j NFQUEUE --queue-num "$sni_queue" --queue-bypass
    ip6tables -w 2 -t filter -C OUTPUT -j AGH_SNI || \
        ip6tables -w 2 -t filter -I OUTPUT 1 -j AGH_SNI
}

# 重建iptables规则
rebuild_rules() {
    iptables -w 2 -t nat -L ADGUARD || {
        iptables -w 2 -t nat -N ADGUARD
        iptables -w 2 -t nat -I OUTPUT -j ADGUARD
    }
    iptables -w 2 -t nat -F ADGUARD
    iptables -w 2 -t nat -A ADGUARD -p udp --dport 53 -j REDIRECT --to-ports "$redir_port"
    iptables -w 2 -t nat -A ADGUARD -p tcp --dport 53 -j REDIRECT --to-ports "$redir_port"
    iptables -w 2 -A OUTPUT -p tcp --dport 853 -j REJECT
    iptables -w 2 -A OUTPUT -p udp --dport 853 -j REJECT --reject-with icmp-port-unreachable
    iptables -w 2 -A OUTPUT -p udp --dport 443 -j REJECT --reject-with icmp-port-unreachable
    ip6tables -w 2 -L ADGUARD6 || {
        ip6tables -w 2 -N ADGUARD6
        ip6tables -w 2 -I OUTPUT -j ADGUARD6
    }
    ip6tables -w 2 -F ADGUARD6
    ip6tables -w 2 -A ADGUARD6 -p tcp --dport 853 -j REJECT
    ip6tables -w 2 -A ADGUARD6 -p udp --dport 853 -j REJECT --reject-with icmp6-port-unreachable
    ip6tables -w 2 -A ADGUARD6 -p tcp --dport 53 -j REJECT
    ip6tables -w 2 -A ADGUARD6 -p udp --dport 53 -j REJECT --reject-with icmp6-port-unreachable
    ip6tables -w 2 -A ADGUARD6 -p udp --dport 443 -j REJECT --reject-with icmp6-port-unreachable
    rebuild_sni
    for s in 1 0; do
        settings put global airplane_mode_on $s
        am broadcast -a android.intent.action.AIRPLANE_MODE
    done
}

# 规则守护循环
while true; do
    . "$AGH_DIR/scripts/config.prop"
    sni_queue=$(sed -n 's/^[[:space:]]*queue_num:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
        "$AGH_DIR/bin/AdGuardHome.yaml" | head -n 1)
    need_restart=0
    agh_running || need_restart=1
    need_fix=0
    iptables -w 2 -t nat -C ADGUARD -p udp --dport 53 -j REDIRECT --to-ports "$redir_port" || need_fix=1
    iptables -w 2 -t nat -C ADGUARD -p tcp --dport 53 -j REDIRECT --to-ports "$redir_port" || need_fix=1
    iptables -w 2 -C OUTPUT -p tcp --dport 853 -j REJECT || need_fix=1
    iptables -w 2 -C OUTPUT -p udp --dport 853 -j REJECT --reject-with icmp-port-unreachable || need_fix=1
    iptables -w 2 -C OUTPUT -p udp --dport 443 -j REJECT --reject-with icmp-port-unreachable || need_fix=1
    ip6tables -w 2 -C OUTPUT -j ADGUARD6 || need_fix=1
    ip6tables -w 2 -C ADGUARD6 -p tcp --dport 853 -j REJECT || need_fix=1
    ip6tables -w 2 -C ADGUARD6 -p udp --dport 853 -j REJECT --reject-with icmp6-port-unreachable || need_fix=1
    ip6tables -w 2 -C ADGUARD6 -p tcp --dport 53 -j REJECT || need_fix=1
    ip6tables -w 2 -C ADGUARD6 -p udp --dport 53 -j REJECT --reject-with icmp6-port-unreachable || need_fix=1
    ip6tables -w 2 -C ADGUARD6 -p udp --dport 443 -j REJECT --reject-with icmp6-port-unreachable || need_fix=1
    iptables -w 2 -t filter -C OUTPUT -j AGH_SNI || need_fix=1
    iptables -w 2 -t filter -C AGH_SNI -o lo -j RETURN || need_fix=1
    iptables -w 2 -t filter -C AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags ALL ACK -j RETURN || need_fix=1
    iptables -w 2 -t filter -C AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags SYN,FIN,RST NONE \
        -j NFQUEUE --queue-num "$sni_queue" --queue-bypass || need_fix=1
    ip6tables -w 2 -t filter -C OUTPUT -j AGH_SNI || need_fix=1
    ip6tables -w 2 -t filter -C AGH_SNI -o lo -j RETURN || need_fix=1
    ip6tables -w 2 -t filter -C AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags ALL ACK -j RETURN || need_fix=1
    ip6tables -w 2 -t filter -C AGH_SNI -p tcp -m multiport --dports "$sni_ports" \
        --tcp-flags SYN,FIN,RST NONE \
        -j NFQUEUE --queue-num "$sni_queue" --queue-bypass || need_fix=1
    [ $need_restart -eq 1 ] && start_agh
    [ $need_fix -eq 1 ] && rebuild_rules
    sleep 5
done &