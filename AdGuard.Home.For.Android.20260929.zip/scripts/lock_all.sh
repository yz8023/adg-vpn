#!/system/bin/sh
# 一键锁定所有广告文件和脚本

AGH_DIR="/data/adb/agh"
ADGPATH="/data/adb/modules/AdGuardHome"

echo "正在锁定文件..."

# 锁定广告文件
if [ -f "$AGH_DIR/scripts/NoAdsService.sh" ]; then
    grep 'block_ad' "$AGH_DIR/scripts/NoAdsService.sh" | grep -o '".*"' | tr -d '"' | while IFS= read -r p; do 
        [ -n "$p" ] && [ -e "$p" ] && {
            if [ -d "$p" ]; then
                chattr +i "$p" 2>/dev/null
            else
                chattr +i "$p" 2>/dev/null
            fi
        }
    done
fi

# 锁定脚本
[ -d "$AGH_DIR/scripts" ] && find "$AGH_DIR/scripts" -type f -name "*.sh" -exec chattr +i {} \;
[ -d "$ADGPATH" ] && find "$ADGPATH" -type f -name "*.sh" -exec chattr +i {} \;

echo "所有文件已锁定"
