#!/system/bin/sh
# ============================================================
#  手动重启脚本 - 修改 yaml 配置后使用，免重启手机
#
#  用法:
#     sh restart.sh            # 重启 AdGuardHome（应用过滤规则修改）
#     sh restart.sh agh        # 同上
#     sh restart.sh box        # 重启 box/mihomo（应用分流配置修改）
#     sh restart.sh box force  # 跳过配置检测直接重启 box
#     sh restart.sh all        # 两者都重启
# ============================================================
AGH_DIR="/data/adb/agh"
BIN_DIR="$AGH_DIR/bin"
AGH_LOG="$AGH_DIR/agh.log"
BOX_DIR="/data/adb/box"
MAIN_LOG="/data/adb/box/run"

log() {
    echo "$(date '+%F %T') [restart] $1" | tee -a "$AGH_LOG"
}

agh_running() {
    for p in /proc/[0-9]*; do
        c=
        IFS= read -r c < "$p/cmdline"
        case "$c" in
        "$BIN_DIR/AdGuardHome"*) return 0 ;;
        esac
    done
    return 1
}

kill_agh() {
    for p in /proc/[0-9]*; do
        c=
        IFS= read -r c < "$p/cmdline"
        case "$c" in
        "$BIN_DIR/AdGuardHome"*) kill "${p#/proc/}" ;;
        esac
    done
}

# 重启 AdGuardHome：kill 后由 iptables.sh 守护循环自动拉起，
# 若守护循环不在运行则直接手动启动
restart_agh() {
    [ -f "$BIN_DIR/AdGuardHome" ] || { log "错误: 未找到 $BIN_DIR/AdGuardHome"; exit 1; }
    [ -f "$BIN_DIR/AdGuardHome.yaml" ] || { log "错误: 未找到 $BIN_DIR/AdGuardHome.yaml"; exit 1; }

    if ! agh_running; then
        log "AdGuardHome 未在运行，直接启动"
    else
        old_port=$(sed -n '/^dns:/,/^[^[:space:]]/s/^[[:space:]]*port:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
            "$BIN_DIR/AdGuardHome.yaml" | head -n 1)
        kill_agh
        # 守护循环每 5 秒检测一次，最多等 12 秒
        i=0
        while [ $i -lt 12 ]; do
            agh_running && break
            sleep 1
            i=$((i + 1))
        done
    fi

    if ! agh_running; then
        log "守护循环未拉起，手动启动 AdGuardHome"
        export SSL_CERT_DIR="/system/etc/security/cacerts/"
        "$BIN_DIR/AdGuardHome" --no-check-update &
        sleep 2
    fi

    if agh_running; then
        log "AdGuardHome 重启成功，新配置已生效"
    else
        log "错误: AdGuardHome 启动失败，请检查 yaml 语法 (tail $AGH_LOG)"
        exit 1
    fi

    # 同步 config.prop 的 redir_port，保证 iptables 劫持与 mihomo 上游一致
    new_port=$(sed -n '/^dns:/,/^[^[:space:]]/s/^[[:space:]]*port:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
        "$BIN_DIR/AdGuardHome.yaml" | head -n 1)
    if [ -n "$new_port" ] && [ -f "$AGH_DIR/scripts/config.prop" ]; then
        old_redir=$(sed -n 's/^redir_port=\([0-9][0-9]*\).*/\1/p' "$AGH_DIR/scripts/config.prop")
        if [ "$new_port" != "$old_redir" ]; then
            sed -i "s/^redir_port=.*/redir_port=$new_port/" "$AGH_DIR/scripts/config.prop"
            log "DNS 端口 $old_redir -> $new_port 已同步至 config.prop"
            log "ProxyConfig.sh 将在数秒内改写 mihomo 上游并重启 box，或手动执行: sh $0 box"
        fi
    fi
}

# 重启 box：mihomo 先做配置检测，失败则中止（force 可跳过）
restart_box() {
    [ -f "$BOX_DIR/scripts/box.service" ] || { log "错误: 未找到 $BOX_DIR/scripts/box.service"; exit 1; }

    bin_name=$(sed -n 's/^bin_name="\([^"]*\)".*/\1/p' "$BOX_DIR/settings.ini" 2>/dev/null)
    [ -n "$bin_name" ] || bin_name="mihomo"

    if [ "$1" != "force" ] && [ "$bin_name" = "mihomo" ] && [ -x "$BOX_DIR/bin/mihomo" ]; then
        log "正在检测 mihomo 配置..."
        if timeout 15 "$BOX_DIR/bin/mihomo" -t -d "$BOX_DIR/mihomo" -f "$BOX_DIR/mihomo/config.yaml" 2>&1 | tee -a "$AGH_LOG"; then
            log "mihomo 配置检测通过"
        else
            log "错误: mihomo 配置检测未通过，已取消重启。确认无误后可执行: sh $0 box force"
            exit 1
        fi
    fi

    log "正在重启 box ($bin_name)..."
    "$BOX_DIR/scripts/box.service" restart
    sleep 3
    if pidof "$bin_name" > /dev/null 2>&1; then
        log "box ($bin_name) 重启成功，新配置已生效"
    else
        log "错误: box ($bin_name) 启动失败，最近日志如下:"
        [ -f "$MAIN_LOG/$bin_name.log" ] && tail -n 20 "$MAIN_LOG/$bin_name.log" | tee -a "$AGH_LOG"
        exit 1
    fi
}

case "$1" in
    ""|agh)
        restart_agh
        ;;
    box)
        restart_box "$2"
        ;;
    all)
        restart_agh
        restart_box "$2"
        ;;
    *)
        echo "用法: sh $0 [agh|box|all] [force]"
        echo "  agh (默认) 重启 AdGuardHome，应用过滤规则修改"
        echo "  box        重启 box/mihomo，应用分流配置修改"
        echo "  all        两者都重启"
        echo "  force      与 box 连用，跳过配置检测"
        exit 1
        ;;
esac
